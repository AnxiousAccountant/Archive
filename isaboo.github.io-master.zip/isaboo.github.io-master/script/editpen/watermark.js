document.write('<div style="width: 100%; position: fixed; bottom: 0px; margin: 0px auto; background-color: grey; color: white; font-family: Arial, Helvetica, sans-serif;">Created with Isaboo htpen. Create your own pages at <a href="http://www.isaboo.co.uk/htpen">isaboo.co.uk/htpen</a></div>');
var link = document.createElement("link");
link.rel = "stylesheet";
link.href = "https://cdn.quilljs.com/1.3.6/quill.snow.css";
document.getElementsByTagName("head")[0].appendChild(link);
