# My Website
This is my website's source code.

I won't be accepting any pull requests but feel free to use this source code anywhere.

*Aslong as it's used under Creative Commons BY-NC-SA (see licence for details)*
