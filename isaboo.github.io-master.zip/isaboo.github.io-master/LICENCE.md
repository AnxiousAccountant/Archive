# Licence

You are free to use this code anywhere aslong as you follow

*__Creative Commons BY-SA v4__*<br>
This means you must give credit to me (*Isaac Boorman*) and must be distributed under the same licence.

https://creativecommons.org/licenses/by-sa/4.0/ before you use this code.
